import React from 'react';

const CyworldToday = () => {
    return (
        <em>TODAY<span>0</span></em>
    );
};

export default CyworldToday;