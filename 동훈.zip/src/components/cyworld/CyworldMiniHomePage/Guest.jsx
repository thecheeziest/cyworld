import React from 'react';

const Guest = () => {
    return (
        <div>
            
        </div>
    );
};

export default Guest;