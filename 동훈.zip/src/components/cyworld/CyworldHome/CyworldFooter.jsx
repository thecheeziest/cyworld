import React from 'react';

const CyworldFooter = () => {
    return (
        <footer>
            ⓒ 2023. 김영은 우동훈 이초롱 조현아 All rights reserved.
        </footer>
    );
};

export default CyworldFooter;