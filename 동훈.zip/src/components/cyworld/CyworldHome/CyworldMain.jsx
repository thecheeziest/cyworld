import React from 'react';

const CyworldMain = () => {
    return (
        <div>
            
        </div>
    );
};

export default CyworldMain;