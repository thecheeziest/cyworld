import React from 'react';

const Minimi = () => {
    return (
        <div>
            미니미샵
        </div>
    );
};

export default Minimi;