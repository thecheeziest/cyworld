import React from 'react';

const Theme = () => {
    return (
        <div>
            테마샵
        </div>
    );
};

export default Theme;