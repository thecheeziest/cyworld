import { createSlice } from '@reduxjs/toolkit';

const initialState = {
   
  };

  export const profileSlice = createSlice({
    name: 'music',
    initialState,
    reducers: {
    
    },
  });
  
//   export const {  } = profileSlice.actions;
  
  export default profileSlice.reducer;